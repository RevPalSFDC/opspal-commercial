# Health Scoring Methodology

## Overall Health Score (0-100)

### Component Weights
| Component | Weight | Score Range |
|-----------|--------|-------------|
| Data Quality | 25% | 0-100 |
| Automation Health | 20% | 0-100 |
| Integration Stability | 15% | 0-100 |
| User Adoption | 15% | 0-100 |
| Reporting Maturity | 15% | 0-100 |
| Security Posture | 10% | 0-100 |

### Calculation
```javascript
overallScore = (dataQuality * 0.25) +
               (automationHealth * 0.20) +
               (integrationStability * 0.15) +
               (userAdoption * 0.15) +
               (reportingMaturity * 0.15) +
               (securityPosture * 0.10);
```

## Data Quality Score

### Sub-Components
| Metric | Weight | Calculation |
|--------|--------|-------------|
| Completeness | 40% | Required fields populated / Total required |
| Accuracy | 25% | Valid format records / Total records |
| Consistency | 20% | Matching records across objects / Total relationships |
| Freshness | 15% | Records updated in 90 days / Total records |

### Thresholds
| Score | Rating | Action Required |
|-------|--------|-----------------|
| 90-100 | Excellent | Maintain current practices |
| 70-89 | Good | Minor improvements |
| 50-69 | Fair | Focused remediation |
| 30-49 | Poor | Immediate attention |
| 0-29 | Critical | Urgent intervention |

## Automation Health Score

### Sub-Components
| Metric | Weight | Good | Warning | Critical |
|--------|--------|------|---------|----------|
| Active Workflow Rate | 30% | >70% | 40-70% | <40% |
| Enrollment Success | 25% | >90% | 70-90% | <70% |
| Error Rate | 25% | <5% | 5-15% | >15% |
| Performance (avg time) | 20% | <1s | 1-5s | >5s |

### Scoring Rules
```javascript
function calculateAutomationScore(metrics) {
  let score = 100;

  // Deduct for inactive workflows
  if (metrics.activeRate < 0.7) score -= (0.7 - metrics.activeRate) * 30;

  // Deduct for enrollment failures
  if (metrics.enrollmentSuccess < 0.9) score -= (0.9 - metrics.enrollmentSuccess) * 25;

  // Deduct for errors
  if (metrics.errorRate > 0.05) score -= (metrics.errorRate - 0.05) * 200;

  // Deduct for slow performance
  if (metrics.avgExecutionTime > 1000) score -= Math.min(20, (metrics.avgExecutionTime - 1000) / 200);

  return Math.max(0, score);
}
```

## Integration Stability Score

### Sub-Components
| Metric | Weight | Calculation |
|--------|--------|-------------|
| Sync Success Rate | 40% | Successful syncs / Total sync attempts |
| Error Resolution Time | 25% | 100 - (avg hours to resolve / 24 * 25) |
| Data Freshness | 20% | Records synced in 4h / Total records |
| Conflict Rate | 15% | 100 - (conflicts / syncs * 100) |

### Integration Types
- **CRM Sync** (Salesforce, Dynamics)
- **Marketing** (LinkedIn, Google Ads)
- **Communications** (Slack, Teams)
- **Data Enrichment** (Clearbit, ZoomInfo)

## User Adoption Score

### Sub-Components
| Metric | Weight | Good | Warning | Critical |
|--------|--------|------|---------|----------|
| Login Frequency | 30% | Daily | Weekly | Monthly |
| Feature Usage | 25% | >75% features | 50-75% | <50% |
| Task Completion | 25% | >90% | 70-90% | <70% |
| Training Completion | 20% | 100% | 75-100% | <75% |

## Reporting Maturity Score

### Maturity Levels
| Level | Score | Characteristics |
|-------|-------|-----------------|
| Level 1: Ad-Hoc | 0-25 | No standard reports, manual exports |
| Level 2: Basic | 26-50 | Standard reports, limited dashboards |
| Level 3: Defined | 51-75 | Department dashboards, scheduled reports |
| Level 4: Managed | 76-90 | Cross-functional dashboards, KPI tracking |
| Level 5: Optimized | 91-100 | Predictive analytics, automated insights |

## Security Posture Score

### Sub-Components
| Metric | Weight | Requirement |
|--------|--------|-------------|
| 2FA Enabled | 30% | >95% users |
| Permission Review | 25% | Within 90 days |
| API Key Rotation | 20% | Within 180 days |
| Audit Log Review | 15% | Within 30 days |
| GDPR Compliance | 10% | All checkboxes met |
