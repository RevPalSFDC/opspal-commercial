---
name: goal-backward-plugin-design
description: Goal-backward methodology for plugin design. Use when designing plugins by working backward from success criteria.
usage: Reference this skill when starting plugin planning to ensure requirements-driven development.
---

# Goal-Backward Plugin Design

This skill documents the goal-backward methodology for designing Claude Code plugins. Instead of asking "What should we build?", we ask "What must be TRUE for this plugin to succeed?"

## Core Principle

**Traditional (Forward) Approach:**
```
Features → Implementation → Hope it works
```

**Goal-Backward Approach:**
```
Success Criteria → Gap Analysis → Targeted Implementation
```

## The Method

### Step 1: Define Success State

Start by describing what success looks like:

```markdown
## Success State: {Plugin Name}

### When This Plugin Succeeds
1. {Observable outcome 1}
2. {Observable outcome 2}
3. {Observable outcome 3}

### Success Metrics
- {Metric 1}: {target value}
- {Metric 2}: {target value}

### User Success Story
"As a {user type}, I can {capability} so that {benefit}."
```

### Step 2: Derive Requirements

Work backward from success to requirements:

```markdown
## Requirements Derivation

### For "{outcome 1}" to be true:
- Must have: {requirement A}
- Must have: {requirement B}

### For "{outcome 2}" to be true:
- Must have: {requirement C}
- Depends on: {requirement A}

### For "{metric 1}" to achieve {target}:
- Must implement: {specific feature}
- Must avoid: {specific anti-pattern}
```

### Step 3: Gap Analysis

Compare requirements to current state:

```markdown
## Gap Analysis

| Requirement | Current State | Gap | Priority |
|-------------|--------------|-----|----------|
| {req A} | {exists/missing/partial} | {description} | P0-P3 |
| {req B} | ... | ... | ... |

### Critical Gaps (P0)
- {gap that blocks success}

### Important Gaps (P1)
- {gap that significantly impacts success}

### Nice-to-Have Gaps (P2-P3)
- {gap that enhances success}
```

### Step 4: Task Generation

Generate tasks to close gaps:

```markdown
## Tasks to Close Gaps

### P0 Tasks (Must Do)
1. {Task to close critical gap 1}
2. {Task to close critical gap 2}

### P1 Tasks (Should Do)
3. {Task to close important gap 1}

### P2-P3 Tasks (Could Do)
4. {Task to enhance}
```

## Example: Plugin Development Plugin

### Success State

```markdown
## Success State: Developer Tools Plugin (GSD Enhancement)

### When This Plugin Succeeds
1. Plugin developers can create quality plugins in 50% less time
2. New plugins consistently pass validation on first attempt
3. Context degradation is avoided through proactive monitoring
4. Development progress is always recoverable after interruptions

### Success Metrics
- First-attempt validation pass rate: > 90%
- Average plugin development time: 4 hours → 2 hours
- Context-related quality issues: 0 per session
- State recovery success: 100%

### User Success Story
"As a plugin developer, I can follow a structured workflow with
context management so that I produce high-quality plugins efficiently."
```

### Requirements Derivation

```markdown
## Requirements Derivation

### For "50% less time" to be true:
- Must have: Structured planning workflow
- Must have: Reusable templates
- Must have: Clear task specifications
- Must avoid: Ad-hoc unplanned development

### For "first-attempt validation pass" to be true:
- Must have: Built-in verification steps
- Must have: Quality gates before completion
- Must have: Clear acceptance criteria
- Must have: Pattern guidance during creation

### For "context degradation avoided" to be true:
- Must have: Context monitoring capability
- Must have: Quality zone awareness
- Must have: Fresh agent spawning guidance
- Must have: State persistence across resets

### For "always recoverable" to be true:
- Must have: State file that survives compaction
- Must have: Pause/resume commands
- Must have: Complete handoff documentation
- Must have: Git integration for checkpoints
```

### Gap Analysis

```markdown
## Gap Analysis

| Requirement | Current | Gap | Priority |
|-------------|---------|-----|----------|
| Structured planning workflow | Missing | No GSD-style planning agents | P0 |
| Reusable templates | Partial | No state/roadmap templates | P1 |
| Context monitoring | Missing | No context tracking | P0 |
| Quality gates | Partial | No pre-completion verification | P1 |
| State persistence | Missing | No PLUGIN_STATE.md pattern | P0 |
| Pause/resume | Missing | No commands for session management | P1 |
```

### Task Generation

```markdown
## Tasks to Close Gaps

### P0 Tasks
1. Create plugin-context-engineer agent
2. Create plugin-phase-planner agent
3. Create PLUGIN_STATE.md template
4. Create /plugin-dev:new-plugin command

### P1 Tasks
5. Create plugin-verifier agent
6. Create /plugin-dev:pause command
7. Create /plugin-dev:resume command
8. Create PLUGIN_ROADMAP.md template
```

## Templates

### Success State Template

```markdown
## Success State: {Plugin Name}

### Vision
{One paragraph describing the ideal future state}

### When This Plugin Succeeds
1. {Observable, testable outcome}
2. {Observable, testable outcome}
3. {Observable, testable outcome}

### Success Metrics
| Metric | Current | Target | How to Measure |
|--------|---------|--------|----------------|
| {metric} | {baseline} | {goal} | {measurement method} |

### User Success Stories
1. "As a {role}, I can {action} so that {benefit}."
2. "As a {role}, I can {action} so that {benefit}."

### Anti-Success (What We're Avoiding)
- {Bad outcome 1 we want to prevent}
- {Bad outcome 2 we want to prevent}
```

### Requirements Derivation Template

```markdown
## Requirements Derivation

### Outcome Analysis
For each success outcome, list what must be true:

#### Outcome 1: {outcome}
To achieve this:
- Must have: {capability/feature}
- Must have: {capability/feature}
- Must avoid: {anti-pattern}
- Depends on: {prerequisite}

#### Outcome 2: {outcome}
To achieve this:
- Must have: ...

### Metric Requirements
For each metric to reach target:

#### {Metric}: {current} → {target}
To achieve this:
- Implement: {specific feature}
- Optimize: {specific aspect}
- Measure: {how we'll track}

### Cross-Cutting Requirements
Requirements that affect multiple outcomes:
- {requirement that enables several outcomes}
```

### Gap Analysis Template

```markdown
## Gap Analysis

### Current State Assessment
{Brief description of what exists today}

### Gap Matrix
| ID | Requirement | Current State | Gap Description | Priority | Effort |
|----|-------------|---------------|-----------------|----------|--------|
| G1 | {req} | {state} | {gap} | P0-P3 | S/M/L |

### Gap Prioritization Rationale

#### P0 - Critical (Blocks Success)
- G{N}: {why this is critical}

#### P1 - Important (Significantly Impacts)
- G{N}: {why this is important}

#### P2 - Beneficial (Enhances)
- G{N}: {why this is nice to have}

#### P3 - Optional (Minor Enhancement)
- G{N}: {why this is optional}

### Dependency Map
```
G1 ──► G3
       ▼
G2 ──► G4
```
{Gap dependencies affect task ordering}
```

### Task Derivation Template

```markdown
## Task Derivation

### Gap-to-Task Mapping

| Gap | Tasks to Close | Phase |
|-----|---------------|-------|
| G1 | T1, T2 | 1 |
| G2 | T3 | 2 |

### Task Specifications

#### T1: {Task Name}
- Closes: G1
- Type: {agent|command|hook|script}
- Dependencies: None
- Context Cost: {small|medium|large}

#### T2: {Task Name}
- Closes: G1
- Type: {type}
- Dependencies: T1
- Context Cost: {size}

### Execution Order
1. T1 (no deps) → 2. T2 (needs T1) → 3. T3 (needs T2)
```

## Anti-Patterns to Avoid

### Feature-First Thinking
```
❌ "Let's add a cool feature!"
✓ "What outcome does this serve?"
```

### Premature Implementation
```
❌ "I'll figure out requirements as I code"
✓ "Define success, then derive requirements, then implement"
```

### Vague Success Criteria
```
❌ "Make the plugin good"
✓ "Plugin passes validation with score >= 90 on first attempt"
```

### Ignoring Dependencies
```
❌ "Let's just build everything"
✓ "G1 must be closed before G3 can be addressed"
```

### Over-Engineering
```
❌ "What if users want X, Y, and Z?"
✓ "What must be true for the defined success state?"
```

## Validation Questions

Use these to validate your design:

### Success State Validation
- [ ] Is each outcome observable and testable?
- [ ] Are metrics specific and measurable?
- [ ] Does the user story capture real value?
- [ ] Is the anti-success list realistic?

### Requirements Validation
- [ ] Does each requirement trace to an outcome?
- [ ] Are requirements specific enough to implement?
- [ ] Are dependencies identified?
- [ ] Are any requirements gold-plating?

### Gap Analysis Validation
- [ ] Is current state accurately assessed?
- [ ] Are gaps prioritized correctly?
- [ ] Are P0 gaps truly blocking?
- [ ] Are effort estimates realistic?

### Task Validation
- [ ] Does each task close a specific gap?
- [ ] Are task dependencies correct?
- [ ] Are context costs reasonable?
- [ ] Is the execution order achievable?

## Integration with Planning

Goal-backward design feeds into plugin-phase-planner:

```
1. Define Success State
   ↓
2. Derive Requirements
   ↓
3. Perform Gap Analysis
   ↓
4. Generate Tasks → PLUGIN_ROADMAP.md
   ↓
5. Execute with plugin-phase-executor
```

## Summary

**Goal-Backward Design:**
1. Start with success definition, not feature list
2. Work backward to derive requirements
3. Analyze gaps between current and required state
4. Generate only tasks that close gaps
5. Prioritize by impact on success

**Key Question:** "What must be TRUE for success?"

**Remember:** If you can't trace a feature to a success outcome, question whether you need it.
