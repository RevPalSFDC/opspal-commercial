# Pre-Component Development Checks

Primary hook source: `hooks/pre-plugin-component.sh`.

## Guidance

Gate component work by context quality and readiness.
