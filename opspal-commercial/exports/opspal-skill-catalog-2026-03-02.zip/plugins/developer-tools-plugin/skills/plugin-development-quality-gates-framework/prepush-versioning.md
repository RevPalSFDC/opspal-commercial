# Prepush Version Bump Enforcement

Primary hook source: `hooks/pre-push-version-check.sh`.

## Guidance

Block pushes where plugin changes lack version bumps.
