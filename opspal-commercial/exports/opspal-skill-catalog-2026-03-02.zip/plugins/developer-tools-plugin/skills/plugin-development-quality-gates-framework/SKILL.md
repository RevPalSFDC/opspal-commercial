---
name: plugin-development-quality-gates-framework
description: Enforce local maintainer quality gates for plugin components via pre-commit, pre-push, and pre-component hooks.
allowed-tools: Read, Grep, Glob
---

# plugin-development-quality-gates-framework

Use this skill when working on hook-driven workflows in this domain.

## Workflow

1. Identify the hook trigger surface and decision points.
2. Validate policy or guardrail behavior before and after change.
3. Capture failure modes, rollback path, and verification checks.

## Routing Boundaries

Use this skill for the specific hook workflow described here.
Defer to adjacent domain skills when the task is primarily about business logic rather than hook enforcement.

## References

- [Precommit Combined Gates](./precommit-gates.md)
- [Prepush Version Bump Enforcement](./prepush-versioning.md)
- [Pre-Component Development Checks](./component-prechecks.md)
