# Precommit Combined Gates

Primary hook source: `hooks/pre-commit-combined.sh`.

## Guidance

Run integrated standards, frontmatter, and tool validations.
