# Adaptive Weight Update Policy

Primary hook source: `hooks/post-task-routing-feedback.sh`.

## Guidance

Update routing confidence and weights from observed performance.
