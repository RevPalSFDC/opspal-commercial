# Task Routing Feedback Capture

Primary hook source: `hooks/post-task-routing-feedback.sh`.

## Guidance

Capture completion outcomes and map to routing features.
