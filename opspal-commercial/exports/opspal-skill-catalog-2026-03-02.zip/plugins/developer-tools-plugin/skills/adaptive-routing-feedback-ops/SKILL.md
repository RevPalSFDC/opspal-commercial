---
name: adaptive-routing-feedback-ops
description: Use hook feedback loops to update adaptive routing weights and improve agent assignment quality.
allowed-tools: Read, Grep, Glob
---

# adaptive-routing-feedback-ops

Use this skill when working on hook-driven workflows in this domain.

## Workflow

1. Identify the hook trigger surface and decision points.
2. Validate policy or guardrail behavior before and after change.
3. Capture failure modes, rollback path, and verification checks.

## Routing Boundaries

Use this skill for the specific hook workflow described here.
Defer to adjacent domain skills when the task is primarily about business logic rather than hook enforcement.

## References

- [Task Routing Feedback Capture](./feedback-capture.md)
- [Adaptive Weight Update Policy](./weight-updates.md)
- [Feedback Safety Controls](./safety-controls.md)
