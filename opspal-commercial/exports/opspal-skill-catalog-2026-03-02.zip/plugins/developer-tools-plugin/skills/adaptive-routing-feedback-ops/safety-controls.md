# Feedback Safety Controls

Primary hook source: `hooks/post-task-routing-feedback.sh`.

## Guidance

Prevent noisy or low-confidence feedback from degrading routing.
