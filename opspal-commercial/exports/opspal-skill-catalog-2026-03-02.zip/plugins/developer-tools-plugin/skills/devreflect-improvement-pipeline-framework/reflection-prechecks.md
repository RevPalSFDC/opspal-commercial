# Reflection Submission Prechecks

Primary hook source: `hooks/pre-reflection-submit.sh`.

## Guidance

Validate reflection payloads before ingestion.
