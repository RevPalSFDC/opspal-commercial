---
name: devreflect-improvement-pipeline-framework
description: Operate the devreflect post-hook pipeline from reflection submission to prevention generation and adaptive updates.
allowed-tools: Read, Grep, Glob
---

# devreflect-improvement-pipeline-framework

Use this skill when working on hook-driven workflows in this domain.

## Workflow

1. Identify the hook trigger surface and decision points.
2. Validate policy or guardrail behavior before and after change.
3. Capture failure modes, rollback path, and verification checks.

## Routing Boundaries

Use this skill for the specific hook workflow described here.
Defer to adjacent domain skills when the task is primarily about business logic rather than hook enforcement.

## References

- [Pipeline Stages and Contracts](./pipeline-stages.md)
- [Hook Deployment and ROI Tracking](./hook-deployment-tracking.md)
- [Reflection Submission Prechecks](./reflection-prechecks.md)
