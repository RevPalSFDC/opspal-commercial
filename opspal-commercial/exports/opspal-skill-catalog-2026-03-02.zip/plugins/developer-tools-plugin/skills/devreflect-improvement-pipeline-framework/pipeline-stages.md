# Pipeline Stages and Contracts

Primary hook source: `hooks/post-devreflect-pipeline.sh`.

## Guidance

Define staged processing from submit to improvement artifact generation.
