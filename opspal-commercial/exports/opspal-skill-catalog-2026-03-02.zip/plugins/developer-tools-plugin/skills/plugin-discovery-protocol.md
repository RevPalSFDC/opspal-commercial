---
name: plugin-discovery-protocol
description: Research depth protocol for plugin development. Use when determining how much research is needed before building.
usage: Reference this skill when assessing research needs at the start of plugin development.
---

# Plugin Discovery Protocol

This skill documents the discovery protocol for determining appropriate research depth before plugin development. It helps avoid both under-researching novel territory and over-researching familiar ground.

## The Protocol: Levels 0-3

```
Level 0: Skip Research      → Established patterns, proceed directly
Level 1: Quick Reference    → Single source, 15 minutes max
Level 2: Standard Research  → Multiple sources, 1-2 hours
Level 3: Deep Dive          → Comprehensive analysis, half day+
```

## Level Assessment Flowchart

```
                        START
                          │
                          ▼
              ┌─────────────────────┐
              │  Have I built this  │
              │  exact thing before?│
              └─────────────────────┘
                    │         │
                   YES        NO
                    │         │
                    ▼         ▼
               LEVEL 0   ┌─────────────────────┐
                         │ Is this a minor     │
                         │ variation of known  │
                         │ pattern?            │
                         └─────────────────────┘
                               │         │
                              YES        NO
                               │         │
                               ▼         ▼
                          LEVEL 1   ┌─────────────────────┐
                                    │ Are there multiple  │
                                    │ valid approaches?   │
                                    └─────────────────────┘
                                          │         │
                                         YES        NO
                                          │         │
                                          ▼         ▼
                                     LEVEL 2   ┌─────────────────────┐
                                               │ Are there major     │
                                               │ unknowns or high    │
                                               │ risks?              │
                                               └─────────────────────┘
                                                     │         │
                                                    YES        NO
                                                     │         │
                                                     ▼         ▼
                                                LEVEL 3   LEVEL 2
```

## Level 0: Skip Research

### When to Use
- Following a well-documented existing pattern
- Similar component already exists in codebase
- Requirements are crystal clear and familiar
- Standard scaffolding with no variations

### Examples
```
✓ Level 0: "Create another agent like plugin-validator"
✓ Level 0: "Add a standard slash command with typical structure"
✓ Level 0: "Create a hook following the existing pattern"
✗ NOT Level 0: "Create a new type of orchestrator" (novel)
```

### Action
```markdown
## Level 0: Skip Research

Rationale: {why this is familiar territory}
Pattern: Following {existing-component.md}
Proceed to: Planning phase directly

Time: 0 minutes
```

## Level 1: Quick Reference

### When to Use
- Single library or API to understand
- Minor variation from known pattern
- Quick clarification needed
- One specific question to answer

### Time Budget
**Maximum: 15 minutes**

### Research Tasks
1. Read one or two reference files
2. Check official documentation
3. Review one similar example

### Examples
```
✓ Level 1: "How do commands define argument hints?"
✓ Level 1: "What's the standard hook event handling?"
✓ Level 1: "What tools should this type of agent have?"
✗ NOT Level 1: "Which of 5 approaches is best?" (need Level 2)
```

### Action
```markdown
## Level 1: Quick Reference

Question: {specific question to answer}
Source: {where to look}
Time budget: 15 minutes

### Reference Checked
- File: {path}
- Key finding: {what was learned}

### Answer
{answer to the question}

### Proceed to Planning
Confidence: High
Time spent: {X} minutes
```

## Level 2: Standard Research

### When to Use
- Multiple approaches are possible
- New technology or integration involved
- Complex requirements need clarification
- Cross-platform or cross-component considerations

### Time Budget
**Target: 1-2 hours**

### Research Tasks
1. Analyze 3-5 similar implementations
2. Read relevant documentation
3. Evaluate multiple approaches
4. Document pros/cons
5. Make recommendation

### Examples
```
✓ Level 2: "Design a new orchestrator agent pattern"
✓ Level 2: "Integrate with a new MCP server"
✓ Level 2: "Create cross-platform synchronization"
✗ NOT Level 2: "Major architectural overhaul" (need Level 3)
```

### Output: DISCOVERY.md

```markdown
## Level 2: Standard Research

### Research Questions
1. {question needing investigation}
2. {question needing investigation}
3. {question needing investigation}

### Sources Analyzed
1. {source}: {findings}
2. {source}: {findings}
3. {source}: {findings}

### Approaches Considered

| Approach | Pros | Cons | Effort | Risk |
|----------|------|------|--------|------|
| A | ... | ... | Low | Low |
| B | ... | ... | Medium | Medium |
| C | ... | ... | High | High |

### Recommendation
**Approach A** is recommended because:
- {reason 1}
- {reason 2}

Trade-offs accepted:
- {acknowledged downside}

### Dependencies Identified
- {external dependency}
- {internal dependency}

### Risks Identified
| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| {risk} | L/M/H | L/M/H | {how to handle} |

### Proceed to Planning
Confidence: Medium-High
Time spent: {X} hours
```

## Level 3: Deep Dive

### When to Use
- Architectural decisions with long-term impact
- Unknown territory with high risk
- Multiple complex systems to integrate
- Need proof-of-concept validation
- Stakeholder decision required

### Time Budget
**Target: Half day to full day**

### Research Tasks
1. Full domain analysis
2. Multiple source synthesis
3. Prototype key components (POC)
4. Document comprehensive findings
5. Present options for decision

### Examples
```
✓ Level 3: "Design plugin marketplace architecture"
✓ Level 3: "Create cross-platform sync framework"
✓ Level 3: "Major refactoring of agent system"
✓ Level 3: "Security-critical authentication integration"
```

### Output: Comprehensive DISCOVERY.md

```markdown
## Level 3: Deep Dive Research

### Domain Analysis
{Comprehensive analysis of the problem domain}

### Technical Landscape
{Technologies, patterns, existing solutions in the space}

### Proof of Concept

#### POC Goal
{What we're validating}

#### POC Implementation
{What we built to test}

#### POC Results
- Hypothesis: {what we expected}
- Outcome: {what happened}
- Learnings: {what we learned}

### Options Analysis

#### Option A: {Name}
**Architecture:**
{Detailed technical approach}

**Pros:**
- {advantage}

**Cons:**
- {disadvantage}

**Effort:** {estimate}
**Risk Level:** {Low/Medium/High}
**Maintenance:** {ongoing cost}

#### Option B: {Name}
...

#### Option C: {Name}
...

### Comparative Matrix
| Criterion | Option A | Option B | Option C |
|-----------|----------|----------|----------|
| Complexity | Low | Medium | High |
| Time to implement | 2 days | 5 days | 10 days |
| Risk | Low | Medium | High |
| Flexibility | Limited | Good | Excellent |
| Maintenance | Low | Medium | High |

### Recommendation
**Option B** is recommended because:
{Detailed rationale}

However, Option A may be preferable if:
{Alternative circumstances}

### Open Questions
{Questions requiring stakeholder input}

### Decision Needed
{Clear description of decision to be made}

### Next Steps After Decision
1. {step if Option A chosen}
2. {step if Option B chosen}
```

## Level Assessment Checklist

Use this checklist to determine the appropriate level:

```markdown
## Discovery Level Assessment: {Plugin/Component Name}

### Basic Familiarity
- [ ] Have I built this exact thing before?
- [ ] Does a near-identical component exist in codebase?
- [ ] Are requirements 100% clear with no ambiguity?

→ If ALL checked: **Level 0**

### Single-Source Clarity
- [ ] Is there just one question I need answered?
- [ ] Can I find the answer in one reference file?
- [ ] Is this a minor variation of a known pattern?

→ If ALL checked: **Level 1**

### Standard Investigation
- [ ] Are there 2-3 reasonable approaches?
- [ ] Do I need to evaluate trade-offs?
- [ ] Is there new tech/integration involved?
- [ ] Will this take > 15 minutes to research?

→ If ANY checked: **Level 2**

### Deep Analysis
- [ ] Are there architectural implications?
- [ ] Is this completely unknown territory?
- [ ] Is the failure cost high?
- [ ] Do I need to validate with a POC?
- [ ] Is stakeholder decision required?

→ If ANY checked: **Level 3**

### Final Assessment
Assessed Level: {0|1|2|3}
Rationale: {why this level}
```

## Time Management

### Strict Time Boxing
| Level | Time Box | Action if Exceeded |
|-------|----------|-------------------|
| 0 | 0 min | N/A |
| 1 | 15 min | Make decision with available info |
| 2 | 2 hours | Document findings, make recommendation |
| 3 | 1 day | Checkpoint, reassess scope |

### Signs You're Over-Researching
- Reading the same sources multiple times
- Seeking "perfect" information
- Delaying to avoid making a decision
- Research scope expanding

### Signs You're Under-Researching
- Starting implementation with unclear requirements
- Choosing approach without considering alternatives
- Ignoring obvious risks or dependencies
- Assuming familiarity without verification

## Research Patterns

### Pattern: Codebase First
```
1. Search codebase for similar implementations
2. Read and understand existing patterns
3. Note variations and why they exist
4. Then check external sources if needed
```

### Pattern: API Documentation
```
1. Official documentation first
2. Note limitations and edge cases
3. Find code examples
4. Verify with quick test if unclear
```

### Pattern: Comparison Matrix
```
1. List all viable approaches
2. Define comparison criteria
3. Score each approach
4. Weight by importance
5. Make data-driven recommendation
```

### Pattern: Risk Assessment
```
1. Identify what could go wrong
2. Assess likelihood and impact
3. Define mitigations
4. Factor into recommendation
```

## Integration with Workflow

```
User Request
     │
     ▼
Level Assessment
     │
     ├── Level 0 ──► Skip to Planning
     │
     ├── Level 1 ──► Quick Reference (15 min)
     │                    │
     │                    ▼
     │               Simple DISCOVERY.md
     │                    │
     ├── Level 2 ──► Standard Research (1-2 hrs)
     │                    │
     │                    ▼
     │               Full DISCOVERY.md
     │                    │
     └── Level 3 ──► Deep Dive (half day+)
                         │
                         ▼
                    Comprehensive DISCOVERY.md
                    + POC + Decision Request
                         │
                         ▼
                    Planning Phase
```

## Summary

| Level | When | Time | Output |
|-------|------|------|--------|
| 0 | Exact pattern exists | 0 | None needed |
| 1 | Single question | 15 min | Brief note |
| 2 | Multiple approaches | 1-2 hrs | DISCOVERY.md |
| 3 | High risk/unknown | 0.5-1 day | Full analysis + POC |

**Key Principle:** Right-size research to novelty and risk. Neither over-research nor under-research serves the goal of efficient, quality development.

**Remember:** Research informs decisions but doesn't replace judgment. Good enough information to proceed is the goal, not perfect information.
