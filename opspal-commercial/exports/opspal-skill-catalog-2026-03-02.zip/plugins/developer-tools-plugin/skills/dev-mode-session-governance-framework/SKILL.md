---
name: dev-mode-session-governance-framework
description: Control local development-mode session hooks, timeout governance, and component test-first enforcement.
allowed-tools: Read, Grep, Glob
---

# dev-mode-session-governance-framework

Use this skill when working on hook-driven workflows in this domain.

## Workflow

1. Identify the hook trigger surface and decision points.
2. Validate policy or guardrail behavior before and after change.
3. Capture failure modes, rollback path, and verification checks.

## Routing Boundaries

Use this skill for the specific hook workflow described here.
Defer to adjacent domain skills when the task is primarily about business logic rather than hook enforcement.

## References

- [Dev Session Mode Governance](./session-mode.md)
- [Pre-Component Test-First Enforcement](./test-first.md)
- [Post-Component State Management](./post-component-state.md)
