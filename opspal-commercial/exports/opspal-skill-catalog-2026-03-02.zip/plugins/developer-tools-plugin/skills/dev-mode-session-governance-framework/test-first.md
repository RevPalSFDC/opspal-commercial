# Pre-Component Test-First Enforcement

Primary hook source: `hooks/pre-plugin-component-test-check.sh`.

## Guidance

Require or warn on missing tests for component changes.
