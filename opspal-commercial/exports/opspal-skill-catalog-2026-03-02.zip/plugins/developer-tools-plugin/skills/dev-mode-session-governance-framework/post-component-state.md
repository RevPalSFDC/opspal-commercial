# Post-Component State Management

Primary hook source: `hooks/post-plugin-component.sh`.

## Guidance

Update state tracking and progress metadata after component work.
