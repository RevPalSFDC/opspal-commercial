# Dev Session Mode Governance

Primary hook source: `hooks/pre-session-dev-mode-check.sh`.

## Guidance

Load and enforce dev mode session policies at startup.
