# Post-Task Completion Validation

Primary hook source: `hooks/post-task-validation.sh`.

## Guidance

Detect completion claims without evidence and flag violations.
