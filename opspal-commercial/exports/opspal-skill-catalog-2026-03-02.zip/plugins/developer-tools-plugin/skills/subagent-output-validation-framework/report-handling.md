# Verification Report Handling

Primary hook source: `hooks/post-subagent-execution.sh`.

## Guidance

Persist and interpret verification reports for remediation.
