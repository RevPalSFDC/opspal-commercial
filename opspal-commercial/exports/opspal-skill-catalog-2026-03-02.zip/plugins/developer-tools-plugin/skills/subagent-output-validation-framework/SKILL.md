---
name: subagent-output-validation-framework
description: Validate subagent outputs and enforce trust/completion quality checks in maintainer workflows.
allowed-tools: Read, Grep, Glob
---

# subagent-output-validation-framework

Use this skill when working on hook-driven workflows in this domain.

## Workflow

1. Identify the hook trigger surface and decision points.
2. Validate policy or guardrail behavior before and after change.
3. Capture failure modes, rollback path, and verification checks.

## Routing Boundaries

Use this skill for the specific hook workflow described here.
Defer to adjacent domain skills when the task is primarily about business logic rather than hook enforcement.

## References

- [Post-Subagent Validation](./post-subagent-validation.md)
- [Post-Task Completion Validation](./post-task-validation.md)
- [Verification Report Handling](./report-handling.md)
