# Post-Subagent Validation

Primary hook source: `hooks/post-subagent-execution.sh`.

## Guidance

Run output validation and report findings per subagent execution.
