---
name: context-engineering-patterns
description: Context quality management patterns from GSD framework. Use when managing context during long plugin development sessions.
usage: Reference this skill when monitoring context fill or deciding when to spawn fresh agents.
---

# Context Engineering Patterns

This skill documents patterns for managing Claude's context window effectively during plugin development sessions. Based on the GET SHIT DONE (GSD) framework's context engineering principles.

## Core Concept: Quality Curve

Claude's output quality correlates inversely with context utilization:

```
Quality vs Context Fill

Quality
  ▲
  │ ████████
  │ ████████████
  │ ████████████████
  │ ████████████████████
  │ ████████████████████████
  │ ████████████████████████████
  │ ████████████████████████████████
  └──────────────────────────────────────► Context %
     0%     30%     50%     70%    100%
     │      │       │       │
   PEAK   GOOD  DEGRADING  POOR
```

## Quality Zones

### PEAK Zone (0-30%)
**Characteristics:**
- Fresh context, maximum clarity
- Optimal for complex architectural decisions
- Best code quality and completeness
- Highest pattern recognition

**Best For:**
- Starting complex agents
- Architectural planning
- Refactoring decisions
- Cross-cutting concerns

### GOOD Zone (30-50%)
**Characteristics:**
- Still high quality output
- Can handle moderate complexity
- Good for continuation of established patterns
- Reliable execution of planned tasks

**Best For:**
- Continuing current task
- Following established patterns
- Standard component creation
- Documentation updates

### DEGRADING Zone (50-70%)
**Characteristics:**
- Quality beginning to decline
- May miss subtle requirements
- Increased repetition
- Pattern matching less reliable

**Signals:**
- Asking for clarification on things already discussed
- Slight inconsistencies in naming/style
- Needing multiple attempts at simple tasks
- Missing requirements from earlier in conversation

**Action:**
- Complete current task
- Then spawn fresh agent

### POOR Zone (70%+)
**Characteristics:**
- Significant quality degradation
- Frequent errors and oversights
- Inconsistent outputs
- Lost context from earlier conversation

**Signals:**
- Forgetting key decisions
- Repeating instructions already given
- Incomplete implementations
- Contradicting earlier work

**Action:**
- Stop current work
- Save state immediately
- Spawn fresh agent

## Fresh Context Pattern

### When to Spawn Fresh

```yaml
spawn_fresh_when:
  mandatory:
    - Context > 70%
    - Quality degradation observed
    - Starting new architectural work

  recommended:
    - Context > 50%
    - Complex task ahead
    - After completing major component
    - Changing focus area

  optional:
    - Context 30-50% with simple tasks
    - Continuing same pattern
    - Quick fixes or updates
```

### How to Spawn Fresh

1. **Save State**: Update PLUGIN_STATE.md with current progress
2. **Prepare Handoff**: Document what fresh agent needs to know
3. **Use Task Tool**: Spawn with clear context

```markdown
## Handoff Package for Fresh Agent

### State File
Location: {path to PLUGIN_STATE.md}

### Current Task
{what needs to be done}

### Key Context
- {decision 1 and why}
- {decision 2 and why}
- {pattern being followed}

### Files to Focus On
- {file 1}
- {file 2}

### Skip This
- {what fresh agent doesn't need to re-learn}
```

### Handoff Quality Checklist

```markdown
Good Handoff:
- [ ] State file is current
- [ ] Next task is clearly defined
- [ ] Key decisions are documented
- [ ] Relevant files are listed
- [ ] Patterns to follow are noted

Poor Handoff:
- "Continue where I left off" (no context)
- "Finish the plugin" (no specifics)
- Missing state file reference
- No decision context
```

## Context Estimation Heuristics

### Token Estimation
```
Base overhead:     ~8,000 tokens (system, tools)
Per message:       ~500 tokens average
Per file read:     ~2,000 tokens average
Per tool call:     ~100 tokens
Complex code:      ~3,000-5,000 tokens
```

### Estimation Formula
```javascript
function estimateContextFill() {
  const base = 8000;
  const messages = messageCount * 500;
  const files = filesRead * 2000;
  const tools = toolCalls * 100;

  const total = base + messages + files + tools;
  const max = 200000;

  return (total / max) * 100;
}
```

### Quick Estimation
```
Messages | Files | Estimate
---------|-------|----------
10       | 3     | ~12%
20       | 6     | ~20%
30       | 10    | ~30%
40       | 15    | ~40%
50       | 20    | ~55%
```

## Task Sizing for Context

### Small Tasks (1,500 tokens)
- Single file modification
- Simple bug fix
- Minor documentation update
- Configuration change

**Can batch:** 3 small tasks per session

### Medium Tasks (3,000 tokens)
- Standard agent creation
- New command implementation
- Script development

**Can batch:** 2 medium tasks per session

### Large Tasks (5,000+ tokens)
- Complex agent with integrations
- Multi-file refactoring
- Architectural changes

**Do alone:** 1 large task per session

### Task Batching Strategy
```
Target: Keep session under 50% context

Session Planning:
- 3 small tasks: ~15% context
- 2 medium tasks: ~20% context
- 1 large task: ~25% context
- Buffer for discussion: ~10%

Total target: 40-50% then spawn fresh
```

## Context Preservation Patterns

### State File Pattern
Always maintain PLUGIN_STATE.md:
```markdown
# Plugin Development State

## Session Info
- Estimated Context: ~{X}%
- Last Updated: {timestamp}

## Key Decisions
{decisions survive context resets}

## Current Progress
{what's done, what's next}
```

### Documentation-as-Memory
Write to files, not just conversation:
```
❌ "Remember that we're using pattern X"
✓ Document pattern X in the component file

❌ "The validation should check Y"
✓ Write the validation code immediately

❌ "We decided to do Z"
✓ Record decision in state file
```

### External Memory
Use files as extended memory:
- PLUGIN_STATE.md - current status
- PLUGIN_ROADMAP.md - full plan
- DISCOVERY.md - research findings
- Decision log in state file

## Practical Workflows

### Start of Session
```
1. Read PLUGIN_STATE.md (establish context)
2. Check context estimate (~10% for fresh)
3. Plan session: which tasks fit in 50%?
4. Execute planned tasks
5. Update state file continuously
```

### Mid-Session Check
```
1. How many messages so far?
2. How many files read?
3. Rough estimate: still < 50%?
4. If approaching 50%: wrap up current task
5. If > 50%: strongly consider fresh agent
```

### End of Session
```
1. Update PLUGIN_STATE.md with progress
2. Document any uncommitted decisions
3. Note next steps
4. If continuing: assess need for fresh agent
```

### Context Reset
```
1. Save everything to state file
2. Commit any complete work
3. Prepare handoff package
4. Spawn fresh agent with handoff
5. Fresh agent reads state file
6. Continue from documented checkpoint
```

## Anti-Patterns

### Context Hoarding
```
❌ "Let me read all the files first"
✓ Read files as needed, incrementally
```

### Conversation Memory
```
❌ Relying on "we discussed earlier"
✓ Write decisions to files immediately
```

### Marathon Sessions
```
❌ 100+ messages without reset
✓ Fresh agent every ~50 messages
```

### Vague Handoffs
```
❌ "Continue the work"
✓ Specific task, files, and context
```

## Quality Signals

### Good Quality Indicators
- Consistent naming throughout
- Remembering requirements from start
- Clean, complete implementations
- Proactive verification

### Degradation Indicators
- Asking about already-discussed topics
- Inconsistent style/naming
- Missing parts of requirements
- Repetitive or verbose responses
- Needing multiple attempts

### Recovery Actions
1. Note current task state
2. Update state file
3. Spawn fresh agent
4. Provide clear handoff

## Summary

**Key Principles:**
1. Context is finite - manage it intentionally
2. Quality degrades with context fill - accept this
3. Fresh context is cheap - use it liberally
4. State files are memory - update them constantly
5. Handoffs should be complete - enable cold start

**Quick Reference:**
```
0-30%:  Do complex work
30-50%: Continue normally
50-70%: Finish task, then spawn fresh
70%+:   Stop and spawn fresh immediately
```

**Remember:** A clean 30-minute session beats a muddled 2-hour session. Fresh context is renewable; quality is the goal.
