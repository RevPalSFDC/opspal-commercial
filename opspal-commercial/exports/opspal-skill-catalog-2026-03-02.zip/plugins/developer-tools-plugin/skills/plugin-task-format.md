---
name: plugin-task-format
description: XML task format specification for plugin development. Use when creating or parsing task specifications.
usage: Reference this skill when defining tasks in PLUGIN_ROADMAP.md or executing tasks.
---

# Plugin Task Format

This skill documents the XML task format used for specifying plugin development tasks. Based on the GSD framework's task specification pattern, adapted for Claude Code plugin development.

## Task Structure Overview

```xml
<task type="{type}">
  <name>{Task N: Action-oriented name}</name>
  <phase>{phase number}</phase>
  <wave>{execution wave}</wave>
  <files>{files to create or modify}</files>
  <dependencies>{prerequisite tasks or "none"}</dependencies>
  <action>{what to do and WHY}</action>
  <verify>{commands to prove completion}</verify>
  <done>{acceptance criteria}</done>
  <context_cost>{small|medium|large} ({estimated tokens})</context_cost>
</task>
```

## Field Specifications

### type
The component type being created.

**Valid values:**
- `agent` - Agent markdown file
- `command` - Slash command markdown file
- `skill` - Skill documentation file
- `hook` - Bash hook script
- `script` - JavaScript utility script
- `template` - Template file
- `manifest` - plugin.json
- `docs` - Documentation file
- `fix` - Bug fix or remediation

### name
Action-oriented task name.

**Format:** `Task N: {verb} {object}`

**Examples:**
```xml
<name>Task 1: Create plugin-validator agent</name>
<name>Task 5: Add verification command</name>
<name>Fix-2: Resolve missing frontmatter</name>
```

### phase
Development phase number.

**Typical phases:**
1. Foundation - Basic structure and core components
2. Core Features - Main functionality
3. Polish - Documentation, testing, quality

### wave
Execution wave within a phase for dependency ordering.

**Rules:**
- Wave 1: No dependencies (can parallelize)
- Wave 2: Depends on Wave 1 items
- Wave 3: Depends on Wave 2 items
- Same-wave tasks can be done in any order

### files
Files to be created or modified.

**Format:** One file per line, relative paths
```xml
<files>
  agents/my-agent.md
  commands/my-command.md
</files>
```

### dependencies
Prerequisite tasks or components.

**Options:**
- `none` - No dependencies
- Task names: `Task 1: Create base agent`
- Component names: `plugin-validator agent must exist`

### action
What to do and why. Include:
- Clear directive
- Key requirements
- Pattern references
- Rationale

```xml
<action>
  Create agent for validating plugin structure.

  Must include:
  - YAML frontmatter with name, description, tools
  - Trigger keywords for routing
  - Core Responsibilities section
  - Verification examples

  Pattern reference: Follow structure of plugin-validator.md

  Why: Needed for quality gate enforcement in the workflow.
</action>
```

### verify
Commands to verify completion.

**Format:** Shell commands that exit 0 on success
```xml
<verify>
  grep -q "^---" agents/my-agent.md
  grep -q "triggerKeywords:" agents/my-agent.md
  node scripts/analyze-agent-quality.js agents/my-agent.md --min-score 80
</verify>
```

### done
Acceptance criteria as checklist items.

```xml
<done>
  - Agent file exists with valid frontmatter
  - Has trigger keywords defined
  - Quality score >= 80
  - Routes correctly on specified keywords
</done>
```

### context_cost
Estimated context consumption.

**Format:** `{size} ({token estimate})`

**Sizes:**
- `small` - < 1,500 tokens
- `medium` - 1,500-3,000 tokens
- `large` - 3,000-5,000 tokens
- `extra-large` - > 5,000 tokens

## Component-Specific Templates

### Agent Task
```xml
<task type="agent">
  <name>Task N: Create {agent-name} agent</name>
  <phase>1</phase>
  <wave>1</wave>
  <files>agents/{agent-name}.md</files>
  <dependencies>none</dependencies>
  <action>
    Create agent for {purpose}.

    Required frontmatter:
    - name: {agent-name}
    - model: sonnet
    - description: {when to use this agent}
    - tools: [{tool list}]
    - triggerKeywords: [{keywords}]

    Content must include:
    - System prompt explaining agent role
    - Core Responsibilities section
    - Process/Workflow section
    - Best Practices section

    Pattern: Follow {reference-agent}.md structure
  </action>
  <verify>
    grep -q "^---" agents/{agent-name}.md
    grep -q "name: {agent-name}" agents/{agent-name}.md
    grep -q "triggerKeywords:" agents/{agent-name}.md
    grep -q "## Core Responsibilities" agents/{agent-name}.md
    node scripts/analyze-agent-quality.js agents/{agent-name}.md --min-score 80
  </verify>
  <done>
    - Agent file exists at agents/{agent-name}.md
    - Valid YAML frontmatter with all required fields
    - Trigger keywords enable routing
    - Quality score >= 80
    - Has Core Responsibilities section
  </done>
  <context_cost>medium (3000 tokens)</context_cost>
</task>
```

### Command Task
```xml
<task type="command">
  <name>Task N: Create {command-name} command</name>
  <phase>2</phase>
  <wave>2</wave>
  <files>commands/{command-name}.md</files>
  <dependencies>Task M: Create {related-agent}</dependencies>
  <action>
    Create slash command for {purpose}.

    Required frontmatter:
    - description: {one-line description}
    - argument-hint: "{argument format}"

    Content must include:
    - Task section with step-by-step instructions
    - Usage Examples section
    - Expected Output section

    Behavior: {what the command does}
    Arguments: {what arguments it accepts}
  </action>
  <verify>
    grep -q "^---" commands/{command-name}.md
    grep -q "description:" commands/{command-name}.md
    grep -q "## Task\|## Usage" commands/{command-name}.md
  </verify>
  <done>
    - Command file exists with valid frontmatter
    - Has description and argument-hint
    - Has Task or Usage section
    - Executes without error when invoked
  </done>
  <context_cost>small (1500 tokens)</context_cost>
</task>
```

### Hook Task
```xml
<task type="hook">
  <name>Task N: Create {hook-name} hook</name>
  <phase>2</phase>
  <wave>1</wave>
  <files>hooks/{hook-name}.sh</files>
  <dependencies>none</dependencies>
  <action>
    Create hook for {event} event.

    Trigger: {when it should fire}
    Action: {what it should do}
    Exit code: 0 for success, non-zero to block

    Must include:
    - Shebang (#!/bin/bash)
    - Comment header explaining purpose
    - Event handling logic
    - Proper exit codes
  </action>
  <verify>
    test -x hooks/{hook-name}.sh
    bash -n hooks/{hook-name}.sh
    head -1 hooks/{hook-name}.sh | grep -q "^#!/bin/bash"
  </verify>
  <done>
    - Hook file exists and is executable
    - Valid bash syntax
    - Correct shebang
    - Handles specified event
    - Returns appropriate exit codes
  </done>
  <context_cost>small (1000 tokens)</context_cost>
</task>
```

### Script Task
```xml
<task type="script">
  <name>Task N: Create {script-name} script</name>
  <phase>2</phase>
  <wave>1</wave>
  <files>scripts/lib/{script-name}.js</files>
  <dependencies>none</dependencies>
  <action>
    Create utility script for {purpose}.

    Functionality:
    - {function 1}
    - {function 2}

    Interface:
    - CLI: {how to invoke from command line}
    - Module: {what to export for require()}

    Must include:
    - JSDoc comments
    - Error handling
    - module.exports for functions
    - CLI entry point if applicable
  </action>
  <verify>
    node --check scripts/lib/{script-name}.js
    node -e "require('./scripts/lib/{script-name}.js')"
    node scripts/lib/{script-name}.js --help 2>/dev/null || true
  </verify>
  <done>
    - Script file exists with valid JavaScript
    - Exports expected functions
    - CLI works if applicable
    - No runtime errors on require
  </done>
  <context_cost>medium (2500 tokens)</context_cost>
</task>
```

### Fix Task
```xml
<task type="fix">
  <name>Fix-N: {issue description}</name>
  <phase>current</phase>
  <wave>immediate</wave>
  <files>{file to fix}</files>
  <dependencies>none</dependencies>
  <action>
    Fix: {what's wrong}
    Root cause: {why it's wrong}
    Solution: {how to fix it}
  </action>
  <verify>
    {verification that fix worked}
  </verify>
  <done>
    - Issue resolved
    - Verification passes
    - No regression
  </done>
  <context_cost>small (500-1000 tokens)</context_cost>
</task>
```

## Wave Assignment Rules

### Wave 1: Independent Tasks
- Plugin manifest
- README skeleton
- Independent agents
- Standalone scripts
- Basic hooks

### Wave 2: First-Order Dependencies
- Commands (may reference agents)
- Skills (may document agents)
- Integration scripts
- Dependent agents

### Wave 3: Second-Order Dependencies
- Cross-component features
- Integration tests
- Documentation that references multiple components

### Wave 4: Final Tasks
- Complete documentation
- Quality verification
- Release preparation

## Execution Rules

### Sequential Execution
Execute tasks in wave order:
1. Complete all Wave 1 tasks
2. Then complete all Wave 2 tasks
3. Then complete all Wave 3 tasks
4. And so on

### Parallel Within Wave
Tasks in same wave can be done in any order:
```
Wave 1:
  - Task A (no dependency)
  - Task B (no dependency)
  - Task C (no dependency)
  ^ Any order, could even be parallel
```

### Dependency Enforcement
```xml
<dependencies>Task 2: Create base agent</dependencies>
```
Task cannot start until dependency is marked complete.

## Verification Patterns

### Shell Command Verification
```xml
<verify>
  # File exists
  test -f {file}

  # File has content
  test -s {file}

  # Pattern present
  grep -q "{pattern}" {file}

  # Multiple patterns
  grep -q "pattern1" {file} && grep -q "pattern2" {file}

  # Script is valid
  node --check {script}

  # Script runs without error
  node {script} --help >/dev/null 2>&1
</verify>
```

### Quality Check Verification
```xml
<verify>
  node scripts/analyze-agent-quality.js {agent} --min-score 80
  node scripts/validate-plugin.js . --quick
</verify>
```

## Best Practices

### 1. Action Clarity
```xml
<!-- Good: Clear what and why -->
<action>
  Create agent for monitoring context quality.

  Why: Prevents quality degradation in long sessions.

  Must include:
  - Quality zone definitions
  - Alert thresholds
  - Fresh agent recommendations
</action>

<!-- Bad: Vague -->
<action>
  Make the context agent.
</action>
```

### 2. Complete Verification
```xml
<!-- Good: Multiple checks -->
<verify>
  grep -q "^---" {file}
  grep -q "name:" {file}
  grep -q "description:" {file}
  node scripts/analyze-agent-quality.js {file}
</verify>

<!-- Bad: Minimal -->
<verify>
  test -f {file}
</verify>
```

### 3. Measurable Done Criteria
```xml
<!-- Good: Specific and measurable -->
<done>
  - Quality score >= 80
  - Has exactly 4 trigger keywords
  - Includes Best Practices section
</done>

<!-- Bad: Vague -->
<done>
  - Agent is good
  - Works properly
</done>
```

### 4. Realistic Context Cost
```
small:    Simple file creation, minor edits
medium:   Standard component, moderate complexity
large:    Complex logic, multiple considerations
x-large:  Architectural decisions, multi-file changes
```

## Summary

The XML task format provides:
- **Clear specification** of what needs to be done
- **Dependency tracking** for correct ordering
- **Verification steps** for quality assurance
- **Context awareness** for efficient execution
- **Traceability** from plan to completion

Use this format in PLUGIN_ROADMAP.md for all development tasks.
